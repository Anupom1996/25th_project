const express =require('express')
const CategoryCollection=require('../model/CatergorySchema')
const router = express.Router()
require('dotenv').config()
const keyverify =require('../verify')
//category insert in bulk
router.post('/api/category/insert',async(req,res)=>
{
    try{
        const data = await req.body
        console.log(data)
        const post = await CategoryCollection.insertMany(data)
        res.status(200).json({
            message:"successful insert category!!!!!",
            post
        })
    }
    catch(e)
    {
        /*res.status(400).json({
            message:"bad request "
        })*/
        res.send(e)
    }
    
})
//category read from database task25
router.get('/api/category/read',async(req,res)=>
{
    
        const data =await CategoryCollection.find({})
        res.status(200).json({
            message:"successfuly search the record",
            data
           
        })
})
//category with product
router.get('/api/categoryWithProduct/read',async(req,res)=>
{
    try{
        
        const post = await CategoryCollection.find({})
        
        .populate('products')
        
        .exec(function(err,user)
        {
            if(err){
                console.log(err)
            }
            else{
                console.log(user)
                res.send(user)
            }
        })
    }catch{
        res.status(404).json({
            message:"not find the record"
        })
    }
})
           
  //user can filter by a category
  //postman  qutation chara name dite hobe
  router.get('/api/category/find/:name',keyverify,async(req,res)=>
{
    
    try{
        const data = req.params.name
        console.log(data)
        const user =await CategoryCollection.find({
           name:req.params.name
        })
        //res.send(user)
            .populate('products')
            .exec(function(err,user)
        {
            if(err){
                console.log(err)
            }
            else{
                console.log("hii")
                console.log(user)
                res.send(user)
            }
        })
        }catch{
            res.status(500).send("not found")
        }

    
})
// update the record from databsase
router.put('/api/update/Category/:name',async(req,res)=>
{
    const a = req.params.name
    console.log(a)
    const entries =Object.keys(req.body)
    const update ={}
    for(let i =0;i<entries.length;i++)
    {
        update[entries[i]]=Object.values(req.body)[i]
    }
    for(let i =0;i<entries.length;i++)
    {
       console.log(update[entries[i]]=Object.values(req.body)[i])
    }
    try{
  
        const post  =await CategoryCollection.updateMany({name:a},{$set:update})
        console.log("aa")
        res.send(post)
    }
    catch{
        res.send("not update the collection")
    }
})
// delete the record the datadbase
router.delete('/api/category/delete/:name',async(req,res)=>
{
    try{
        const del = await CategoryCollection.find({name:req.params.name}).remove()
        res.send(del)
        
    }
    catch(e){
        res.send(e)
    }

})
module.exports =router