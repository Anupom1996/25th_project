const express =require('express')
const ProductsCollection = require('../model/productschema')
const CategoryCollection=require('../model/CatergorySchema')
const router = express.Router()
router.post('/api/product/insert',async(req,res)=>
{
    try{
        const data = await req.body
        console.log(data)
        const post = await ProductsCollection.insertMany(data)
        res.status(200).json({
            message:"successful insert!!!!!",
            post
        })
    }
    catch(e)
    {
        res.send(e)
    }
    
})
//product read only product
router.get('/api/onlyproduct/read',async(req,res)=>
{
    try{
        const data = await ProductsCollection.find({})
        .populate('categoryId')
        .exec(function(err,user)
        {
            if(err){
                console.log(err)
            }
            else{
                console.log(user)
                res.send(user)
            }
        })
    }catch{
        res.status(404).send("not found the record")
    }
})
//
router.get('/api/read/product',async(req,res)=>
{
    const page =parseInt(req.query.page)
    const limit =parseInt(req.query.limit)
    console.log(page)
    console.log(limit)
    const start = (page-1)*limit
    const end = page*limit
    const results={}
    results.Previous={
        page:page-1,
        limit:limit
    }
    results.next={
        page:page+1,
        limit:limit
    }
   //const result = Pracollection.find({}).slice(start,end)
    for (const key in req.query) {
        console.log(key, req.query[key])
      }

    try{
        
        //const result =  await Pracollection.slice(start,end)
        console.log("aa")
        //const post =await (await Pracollection.find({})).sort({name:-1}).slice(start,end)
        const post = await ProductsCollection.find({}).sort({price:-1})
        const data =post.slice(start,end)
        res.send(data)
        
    
    
    }catch(e){
        res.send(e)
    }
    
})



//
///find the product by a range
router.get('/api/product/Betweenrange',async(req,res)=>
{
    const a = parseInt(req.query.h)
    console.log(a)
    const b = parseInt(req.query.l)
    console.log(b)
    try{
        const data1 = await ProductsCollection.find({"price":{$gte:b,$lte:a}})
        .populate('categoryId')
        .exec(function(err,user)
        {
            if(err){
                console.log(err)
            }
            else{
                console.log(user)
                res.send(user)
            }
        })
        if(data1 == '')
        {
            res.status(404).send("not find the record")
        }
        
    }catch{
        res.send.json({
            message:"errore"
        })
    }
     
    
})
//find the product usile like operator 
// if i want to search pro so shoew  the product

router.get('/api/productfind/like/:name',async(req,res)=>
{
    const name1 = req.params.name
    console.log(name1)
    const b =RegExp('.*'+ name1 + '.*','i')   //case sensetive r jonno
    
    try{
        //const data = await ProductsCollection.find( {"name": {$regex:('.*'+ name1 + '.*')}})
        
        const data = await ProductsCollection.find( {"name": b})
       
        .populate('categoryId')
        .exec(function(err,user)
        {
            if(err){
                console.log(err)
            }
            else{
                console.log(user)
                res.send(user)
            }
        })
    //res.send(data)
    }catch{
        res.send("notfind")
    }
    
})
// update the record from databsase product
router.put('/api/product/upadate/:name',async(req,res)=>
{
    const a = req.params.name
    console.log(a)
    const entries =Object.keys(req.body)
    const update ={}
    for(let i =0;i<entries.length;i++)
    {
        update[entries[i]]=Object.values(req.body)[i]
    }
    for(let i =0;i<entries.length;i++)
    {
       console.log(update[entries[i]]=Object.values(req.body)[i])
    }
    try{
  
        const post  =await ProductsCollection.updateMany({name:a},{$set:update})
        console.log("aa")
        res.send(post)
    }
    catch{
        res.send("not update the collection")
    }
})
// delete the record the datadbase
router.delete('/api/product/delete/:name',async(req,res)=>
{
    try{
        const del = await ProductsCollection.find({name:req.params.name}).remove()
        res.send(del)
        
    }
    catch(e){
        res.send(e)
    }

})

/*router.post('/api/together/product',async(req,res)=>
{
    const a =req.body.name
    const b =req.body.isActive
    const c = req.body.price
   // const c =req.body.price.max
    //const d = req.body.price.min
    console.log(a)
    console.log(b)
    console.log(c)
    //console.log(d)
try
{
        if(a == '' && b == '' & c == '')
    {
        console.log("aa")
        const f =  await ProductsCollection.find({})
       res.send(f)
    }
    if(a != '' && b != '' && c != '')
    {
        const data = await ProductsCollection.find({$and:[{name:a},{isActive:b},{price:c}]})
    res.send(data)
    }
    if(a != '' || b != '' || c != '')
    {
        if(a!='')
        {
            console.log("ak3")
            if(b!='')
            {
                console.log("ak2")
                const data = await ProductsCollection.find({$and:[{name:a},{isActive:b}]})
                res.send(data)
            }
            if(c!='')
            {
                console.log("ak1")
                const data = await ProductsCollection.find({$and:[{name:a},{price:c}]})
                res.send(data)
            }
            else{
                console.log("ak")
                const data = await ProductsCollection.find({name:a})
                    res.send(data)
            }
           
        }

        else if(b!='')
        {
           
            if(c!='')
            {
                console.log("bk1")
                const data = await ProductsCollection.find({$and:[{isActive:b},{price:c}]})
                res.send(data)
            }
            else{
                console.log("bk2")
                const data = await ProductsCollection.find({isActive:b})
                    res.send(data)
            }
           
        }
        else
        {
            console.log("price")
            const data = await ProductsCollection.find({price:c})
            res.send(data)
        }
    }

}catch
    {
        res.send("err")
    }
    

})*/




////price add
router.post('/api/together1/product1',async(req,res)=>
{
    const a =req.body.name
    const b =req.body.isActive
    //const c = req.body.price
    const c =req.body.price.max
    const d = req.body.price.min
    console.log(a)
    console.log(b)
    console.log(c)
    console.log(d)
try
{
        if(a == '' && b == '' & c == '' && d =='')
    {
        console.log("aa")
        const f =  await ProductsCollection.find({})
        .populate('categoryId')
        .exec(function(err,user)
        {
            if(err){
                console.log(err)
            }
            else{
                console.log(user)
                res.send(user)
            }
        })
    }
    else if(a != '' && b != '' && c != '' && c!='' && d!='' )
    {
        const data = await ProductsCollection.find({$and:[{name:a},{isActive:b},{price:{$gte:d,$lte:c}}]})
        .populate('categoryId')
        .exec(function(err,user)
        {
            if(err){
                console.log(err)
            }
            else{
                console.log(user)
                res.send(user)
            }
        })
    }
    else if(a != '' || b != '' || c != '' || d !='')
    {
        if(a!='')
        {
            console.log("ak3")
            if(b!='')
            {
                console.log("ak2")
                const data = await ProductsCollection.find({$and:[{name:a},{isActive:b}]})
                res.send(data)
            }
            else if(c!='' && d!='')
            {
                console.log("ak1")
                const data = await ProductsCollection.find({$and:[{name:a},{price:{$gte:d,$lte:c}}]})
                res.send(data)
            }
            else if(c!='')
            {
                console.log("ak11")
                const data = await ProductsCollection.find({$and:[{name:a},{price:{$lte:c}}]})
                res.send(data)
            }
            else if(d!='')
            {
                console.log("ak22")
                const data = await ProductsCollection.find({$and:[{name:a},{price:{$gte:d}}]})
                res.send(data)
            }
            else{
                console.log("ak")
                const data = await ProductsCollection.find({name:a})
                    res.send(data)
            }
           
        }

        else if(b!='')
        {
           
            if(c!='' && d!='')
            {
                console.log("bk1")
                const data = await ProductsCollection.find({$and:[{isActive:b},{price:{$gte:d,$lte:c}}]})
                res.send(data)
            }
            else if(c!='')
            {
                console.log("ak33")
                const data = await ProductsCollection.find({$and:[{isActive:b},{price:{$lte:c}}]})
                res.send(data)
            }
            else if(d!='')
            {
                console.log("ak44")
                const data = await ProductsCollection.find({$and:[{isActive:b},{price:{$gte:d}}]})
                res.send(data)
            }
            else{
                console.log("bk2")
                const data = await ProductsCollection.find({isActive:b})
                    res.send(data)
            }
           
        }
        else
        {
            console.log("price")
            const data = await ProductsCollection.find({price:{$gte:d,$lte:c}})
            .populate('categoryId')
            .exec(function(err,user)
            {
                if(err){
                    console.log(err)
                }
                else{
                    console.log(user)
                    res.send(user)
                }
            })
        }
    }

}catch(e)
    {
        res.send(e)
    }
    

})
module.exports=router 