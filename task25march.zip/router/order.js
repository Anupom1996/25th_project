const express =require('express')
const OrderSCollection = require('../model/orderschema')
const router = express.Router()
router.post('/api/order/bulkinsert',async(req,res)=>
{
    try{
        const data = await req.body
        console.log(data)
        const post = await OrderSCollection.insertMany(data)
        res.status(200).json({
            message:"successful insert!!!!!",
            post
        })
    }
    catch(e)
    {
       res.send(e)
    }
    
})
router.post('/api/order/singleinsert',async(req,res)=>
{
    const data = await OrderSCollection(req.body)
    console.log(data)
    try{
        const post = await data.save()
        res.send(post)
    }catch (e)
    {
        res.send(e)
    }
})
router.get('/api/read/order',async(req,res)=>
{
    const page =parseInt(req.query.page)
    const limit =parseInt(req.query.limit)
    console.log(page)
    console.log(limit)
    const start = (page-1)*limit
    const end = page*limit
    const results={}
    results.Previous={
        page:page-1,
        limit:limit
    }
    results.next={
        page:page+1,
        limit:limit
    }
   //const result = Pracollection.find({}).slice(start,end)
    for (const key in req.query) {
        console.log(key, req.query[key])
      }

    try{
        
        //const result =  await Pracollection.slice(start,end)
        console.log("aa")
        //const post =await (await Pracollection.find({})).sort({name:-1}).slice(start,end)
        const post = await OrderSCollection.find({}).sort({createdAt:1})
        const data =post.slice(start,end)
        res.send(data)
        
    
    
    }catch(e){
        res.send(e)
    }
    
})

//deep level order find order with product with category
router.get('/api/onlyorder/read',async(req,res)=>
{
    
       try{
        const data = await OrderSCollection.find({})
        .populate('productId')
        .populate({
            path: 'productId',
            populate: {
                path: 'categoryId'
                
                
            }
        })
        
        .exec(function(err,result)
        {
            if(err)
            {
                res.send('errore')
            }
            else{
                res.send(result)
            }
        })
       }
       catch(e)
       {
           res.send(e)
       }
})
// update the order record from databsase product
router.put('/api/order/upadate/:name',async(req,res)=>
{
    const a = req.params.name
    console.log(a)
    const entries =Object.keys(req.body)
    console.log(entries)
    const update ={}
    for(let i =0;i<entries.length;i++)
    {
        console.log("aa")
        update[entries[i]]=Object.values(req.body)[i]
    }
    for(let i =0;i<entries.length;i++)
    {
       console.log(Object.values(req.body)[i])
    }
    try{
        
        const post  = await OrderSCollection.updateMany({name:a},{$set:update},function(err,result){
           if(err)
            {
                res.send(err)
            }
            else{
                res.send(result)
            }
        })
       
    }
    catch{
        res.send("not update the collection")
    }
})
// delete the order record the datadbase
router.delete('/api/order/delete/:name',async(req,res)=>
{
    try{
        const del = await OrderSCollection.find({name:req.params.name}).remove()
        res.send(del)
        
    }
    catch(e){
        res.send(e)
    }

})
//find out threr product betwwebn range
router.get('/api/product/betweenrange/',async(req,res)=>
{
    console.log(req.query.h)
    console.log(req.query.l)
    try{
        const data = await OrderSCollection.find({price:{$gte:l,$lte:h}},(err,res)=>
        {
            if(err)
            {
                res.send("not find the record")
            }else{
                res.send(res)
            }
        })

    }catch(e){
        res.send(e)
    }
  
})
////api last 7 adys
router.get('/api/last7days',async(req,res)=>
{
    
    try{
        const a =new Date((new Date().getTime()-(7 * 24 * 60 * 60 * 1000)))
        console.log(a)
        const post = await  OrderSCollection.find({
            "createdAt":{
                $gte:new Date((new Date().getTime()-(7 * 24 * 60 * 60 * 1000)))
            }
        }).sort({"createdAt":-1})
        res.send(post)
        res.status(200).send()
    }catch{
        res.status(404).json({
            
   
            message:"not find the record"
        })
    }
})
module.exports=router 