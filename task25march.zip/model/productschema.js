const mongoose=require('mongoose')
const validator = require('validator')
const ProductsSchema =  new mongoose.Schema({
    name:
    {
        type:String,
        required:true,
        minlength:3,
        unique:true
    },
    isActive:
    {
        type:Boolean,
        required:true
    },
    createdAt:
    {
        type:Date,
        default:Date.now()
    },
    price:
    {
        type:Number,
        required:true,
        validate(value)
        {
            if(value<=0)
            {
                return resizeBy.send("invalid price")
            }
        }

    },
    categoryId:
    {
        type:mongoose.Schema.Types.ObjectId,
        ref:'CategoryCollection',
        required:true
    }
})
const ProductsCollection  = mongoose.model('ProductsCollection',ProductsSchema)
module.exports = ProductsCollection