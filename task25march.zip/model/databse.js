const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/newtask25',{
    useNewUrlParser:true,
    useUnifiedTopology:true
},(err)=>
{
    if(err)
    {
        console.log("database is not connected")
    }
    else{
        console.log("databse is connected")
    }
})