const mongoose=require('mongoose')
//const validator = require('validator')
const OrderSSchema =  new mongoose.Schema({
   useremail:
   {
       type: String,
       required:true,unique:true
   },
       /*validate(value) {
        if (!validator.isEmail(value)) {
            throw new Error('Email is invalid')
        }
       }*/
   
   name:
    {
        
        required:true,
        minlength:3,
        type:String
        //unique:true
        
    },
   productId:
   {
       type:mongoose.Schema.Types.ObjectId,
       ref:'ProductsCollection',
       required:true
   },
    createdAt:
    {
        type:Date,
        default:Date.now()
    }  
})
const OrderSCollection  = mongoose.model('OrderSCollection',OrderSSchema)
module.exports = OrderSCollection