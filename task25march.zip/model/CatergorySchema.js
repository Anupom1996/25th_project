const mongoose = require('mongoose')
const CategorySchema = new mongoose.Schema({
    name:
    {
        type:String,
        required:true
    },
    isActive:
    {
        type:Boolean,
        required:true
    },
    createdAt:
    {
        type:Date,
        default:Date.now()
    }
})
CategorySchema.virtual('products', {
    ref: 'ProductsCollection',                                      // The model to use
    localField: '_id',                                  // Find people where `localField`
    foreignField: 'categoryId',                            // is equal to `foreignField`
                                                            // If `justOne` is true, 'members' will be a single doc as opposed to
                                                          // an array. `justOne` is false by default.
    justOne: false,
                                                                 //options: { sort: { name: -1 }, limit: 5 } // Query options, see http://bit.ly/mongoose-query-options
  })
  CategorySchema.set('toObject', { virtuals: true })
  CategorySchema.set('toJSON', { virtuals: true })
const CategoryCollection = mongoose.model('CategoryCollection',CategorySchema)
module.exports=CategoryCollection