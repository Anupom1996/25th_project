
function keyverify(req,res,next)
{
    require('dotenv').config()
    const BerearHeader=req.headers['key']
    if(typeof BerearHeader!='undefined')
    {
        const berar = BerearHeader.split(' ')
        const berarToken = berar[1]
        req.token = berarToken
        if(req.token == process.env.key)
        {
            console.log(req.token)
            //res.send("key is match")
            next()
        }
        else{
            res.send("key is not match")
        }
    }
    else{
        res.send("you miss your api key")
    }
    
}
module.exports=keyverify